# SportSignal — Hero Redesign Specification

## 1. Product objective

The homepage Hero should communicate three things within a few seconds:

1. **Which match is featured?** Show both teams and the competition.
2. **When does it start?** Show the kickoff time, date, and a trustworthy countdown when appropriate.
3. **Why should the user care?** Create an energetic, professional, memorable experience for following European football.

The Hero must not be merely decorative. Information hierarchy comes first: visual effects and decoration should reinforce the match information, not compete with it.

## 2. Art direction

Internal concept name: **Stadium Pulse + Match Protocol**.

Combine two visual approaches:

- **Stadium Pulse:** cinematic stadium atmosphere, depth, floodlights, dark gradients, contrast, and the sense of a major event.
- **Match Protocol:** restrained HUD frames, precise light lines, compact status markers, and controlled gaming/eSports energy.

The result should feel like a modern sports product—not a betting interface, not a video game UI, and not a cluttered dashboard. Do not introduce betting claims, odds, predictions, or unrelated elements.

## 3. Scope

### Included

- Redesign of the main featured-match Hero card/banner.
- Hero background media. Reusing the existing stadium video or image is optional; it may be replaced if appropriate.
- Layout for home and away teams, crests, kickoff time, date, countdown, competition, and venue.
- UI surfaces, gradients, borders, lighting, and animations.
- An intentionally responsive mobile composition.
- Designed dark and light themes.
- Continued use of the real match data and existing product logic.

### Excluded from this phase

- **Generating or commissioning bespoke player images.** This is explicitly deferred.
- A full redesign of the global site header, content cards below the Hero, tables, or other page sections, unless a small necessary change is required for Hero integration.
- Building a new API, scraper, or match-data source.
- Unnecessary changes to the framework, architecture, or existing libraries.

### Player-artwork rule

A concept mockup may show player portraits on the outer sides, but the current implementation must not depend on fake images, assumed URLs, or files that do not exist. For now, complete the composition with stadium media, actual team crests, and UI elements. If useful, leave a simple optional extension point for future player artwork, without rendering an obvious empty slot. Do not generate player images or use unrelated footballers to fill space.

## 4. Design principles

1. **The match comes first:** kickoff time and both teams should be immediately recognizable.
2. **Readable over motion:** text must remain legible across bright and dark frames when a video or image background is used.
3. **Controlled contrast:** neon colors and glows are accents; do not make every edge glow continuously.
4. **RTL first:** Persian UI is right-to-left. Dates, digits, team names, and labels must follow the project's font and locale conventions.
5. **Two intentional themes:** do not create light mode by merely inverting dark-mode colors. Use bright surfaces, navy text, and restrained lighting.
6. **Real content only:** team names, crests, times, dates, competition, venue, and status must come from the application's data model. Do not hardcode mock data into production components.
7. **No meaningless clutter:** avoid decorative English labels and HUD elements that communicate nothing. UI copy must be localized.

## 5. Hero information hierarchy

Prioritize information in this order:

1. Competition name/mark, for example the UEFA Champions League.
2. Home and away teams with their real crests.
3. Highly visible kickoff time.
4. Localized match date.
5. A real countdown to kickoff when the match is upcoming.
6. Venue and useful secondary metadata, when valid data exists.
7. A CTA to view/follow upcoming matches only if a real destination or existing capability is present, or can be implemented safely with minimal changes.

### Mockup content is illustrative only

Names such as Barcelona and Paris Saint-Germain, a kickoff time such as 22:30, and any sample date are illustrative. Never hardcode them into the production component. The Hero must display the actual match selected by the existing product logic.

## 6. Desktop visual structure

Size the Hero based on actual content and the existing page layout. Avoid a fragile fixed height. As a starting point, a wide card inside the existing content container may have an apparent height around 250–340px on large displays, but adapt the final size to the repository's layout.

### Layers

- **Layer 0 — Background:** cinematic stadium image or video. Prefer suitable local assets; do not use fragile third-party hotlinks. An existing stadium video may be reused, but preserving it is not mandatory.
- **Layer 1 — Contrast overlay:** localized dark gradient to maintain readability. Provide enough contrast behind text without flattening the entire scene into one uniform color.
- **Layer 2 — Ambient lighting:** restrained blue and green glows implemented with CSS.
- **Layer 3 — Match content:** visually place the home team on the left, kickoff/date in the center, and away team on the right, unless the existing product layout suggests a better established convention. Use CSS Grid named areas or an equivalent robust layout so breakpoints remain controllable.
- **Layer 4 — Secondary information:** competition, venue, status, and countdown in clearly differentiated panels or chips.
- **Layer 5 — UI details:** subtle border, status marker, hover glow for interactive elements, and restrained HUD details.

### Teams

- Preserve each crest's aspect ratio; never stretch it.
- Place the team name close to its crest. Avoid wrapping at common desktop sizes unless a name is unusually long.
- Label home/away roles in Persian when the role is reliably available in the data.
- Oversized background crests are optional. If used, keep opacity low and ensure they do not conflict with foreground content.
- Do not generate large player images in the current phase. The Hero must look complete without them.
- Future player-artwork convention: one standard front-facing artwork image per selected representative player/team, using varied poses. Do not generate separate left-facing/right-facing variants and do not mirror artwork automatically. See `specs/image-assets-and-placeholders.md`.

### Center match panel

- Kickoff time is the primary information block.
- Use strong font weight, tabular digits where supported, and adequate spacing.
- Place the date close to the time with lower visual emphasis.
- A blue panel or restrained HUD frame is appropriate. Do not stack multiple exaggerated effects around it.

### Countdown

- On desktop, the countdown may use four groups for days, hours, minutes, and seconds.
- Keep values and unit labels distinct and legible.
- Calculate the countdown from the actual kickoff timestamp and update it live.
- Keep it readable when kickoff is far away. Use leading zeroes and unit labels according to the existing localization pattern.
- If kickoff data is missing or invalid, do not show a fake countdown.

## 7. Mobile composition

Mobile must be an intentional layout, not simply a scaled-down desktop version.

Suggested order:

1. A compact competition or match-status row at the top.
2. Both teams in two columns, with readable crests and names.
3. Kickoff time and date in a dedicated high-clarity row or center panel.
4. Countdown in a full-width strip or compact four-unit grid.
5. Venue and secondary information as concise chips at the bottom.
6. A CTA only when a real destination exists and there is enough room.

Rules:

- Do not create horizontal scrolling at viewport widths from 320px to 430px.
- Team names must not be squeezed excessively by crests or the countdown.
- If elements are clickable, provide suitable touch target sizes and spacing.
- Let Hero height follow content; avoid fixed heights that clip text on mobile.
- Background media may use a different position/crop on mobile. Never shrink the entire desktop frame into a narrow viewport.
- Reduce decorative HUD details on mobile. Do not shrink primary information just to fit decoration.

## 8. Match states

Use the status values in the existing data model, and do not change the current featured-match selection logic without a concrete reason. Support the following states when the data provides enough information:

- **Upcoming:** kickoff time/date plus countdown.
- **Live:** clear, accessible LIVE status and elapsed minute/time only when valid data exists; do not show a future kickoff countdown.
- **Finished:** finished status and score only when a real result exists.
- **Postponed/Cancelled:** show the appropriate state only when supplied by authoritative match data; hide an invalid countdown.
- **Missing data:** hide unknown fields or use a neutral fallback. Never invent values.

Never switch a match to LIVE merely because its kickoff time is near or a local timer reaches zero. The status must come from match data.

## 9. Background and media

- Prefer a cinematic stadium atmosphere with floodlights and depth, but avoid a busy background directly behind all text.
- Inspect available stadium assets before choosing or creating a new treatment.
- If the project already uses a video and it is suitable for quality and performance, it may be kept; the specification does not require video.
- Background video must be silent and, if used, configured with appropriate autoplay/loop/muted/playsInline behavior for the browser and project.
- Provide a poster/fallback and sensible behavior for reduced-motion or data-saving contexts.
- Avoid heavy assets and external images without a fallback.

## 10. Motion and gaming energy

Use purposeful motion in three layers:

- **Ambient:** a gentle blue/green glow intensity shift, around 8–12 seconds with a low amplitude.
- **Interactive:** a subtle border glow and 2–3px movement on hover for genuinely interactive elements.
- **State changes:** a short, non-disruptive transition when match data or status changes; no sudden flashes.
- **Countdown:** only the digits should change. The entire card must not pulse or reflow every second.

Avoid:

- Continuous flashing or strobing.
- Heavy parallax or fast automatic movement.
- Large scaling/jumping of the whole Hero.
- Animations that repeatedly change layout or cause layout shift.
- Decorative English labels such as `GAME ON`, `NEXT EVENT`, or `MATCH PROTOCOL` in the Persian UI unless they are already part of the brand identity.

## 11. Interaction and calls to action

- Anything that looks clickable must perform a real action; do not create decorative/inert buttons.
- A CTA must lead to a real route or destination in the existing project. If no destination exists, omit the CTA rather than inventing one.
- Apply hover styling only on devices with actual hover input. Avoid sticky/unpredictable hover behavior on touch devices.
- Provide clear `focus-visible` styling for keyboard navigation.
- Preserve existing site language and theme controls.

## 12. Language and RTL

- Persian is the primary UI language and must follow the existing `dir="rtl"` and layout conventions.
- Reuse the project's current font; do not introduce a new external font just for the Hero.
- If i18n exists, connect strings to the existing localization system instead of hardcoding Persian copy in the component, unless hardcoding is the project's established pattern.
- English must preserve the same information hierarchy with layout adapted to locale direction.
- Use the date/time formatters and timezone conventions already used by the project. Do not guess a timezone or silently display UTC as local time.
- Protect mixed Persian/Latin strings such as competition names and times from bidi issues. Use `dir="ltr"` for numeric/time sub-blocks when needed.

## 13. Experience success criteria

After a quick glance, users should be able to identify:

- Both teams.
- The kickoff time.
- How long remains until kickoff, if the match is upcoming.
- The competition.

Background media and visual effects should create excitement, but match information must remain more visually prominent than decoration.
