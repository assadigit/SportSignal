# Image Assets, Placeholders, and Future Player-Artwork Contract

This document defines the image slots and standardized dimensions for the SportSignal Hero. The dimensions below are **source-asset targets**, not CSS display dimensions. The existing app may use a different static-assets directory; first inspect the repository and adapt the paths while preserving the naming/metadata contract.

## 1. Asset principles

- Do not generate any images during the current Hero implementation task.
- Player artwork is intentionally deferred to a later phase. Implement the Hero so it looks complete with no player artwork present.
- Prefer existing local/project-managed assets over external hotlinks.
- Team crests and competition marks should come from the real project data/assets. They are not to be re-generated as illustrations.
- Missing optional imagery must never produce a broken-image icon, a conspicuous empty slot, or layout shift.
- Treat the image names below as logical asset keys. If the repository uses a different asset pipeline or remote media service, map them into that pipeline instead of forcing a new folder structure.

## 2. Asset-slot manifest

| Slot ID / placeholder | Purpose | Preferred source format and source size | Aspect ratio / alpha | Desktop display guidance | Mobile display guidance | Current phase |
|---|---|---|---|---|---|---|
| `HERO_STADIUM_BACKGROUND` — `{{HERO_STADIUM_BACKGROUND}}` | Main stadium image used behind the match UI, if using a still background | AVIF or WebP, target 1920 × 900 px; 2560 × 1200 px for high-density/large screens if justified | About 2.13:1; no transparency required | Cover the Hero container; use `object-fit: cover`/`background-size: cover` and tune the focal point | Reposition/crop with a mobile-specific focal point; do not shrink the whole desktop frame into a narrow container | Existing asset may be reused or replaced, subject to project asset availability; do not add a remote hotlink |
| `HERO_STADIUM_POSTER` — `{{HERO_STADIUM_POSTER}}` | Poster/fallback for an existing or future stadium loop video | WebP or AVIF, target 1920 × 900 px | About 2.13:1; no alpha required | Match the background video crop | Use appropriate `object-position`; provide a stable visual when video is paused/unavailable | Use only if the project uses a background video or needs a poster/fallback; do not create in this phase |
| `HOME_TEAM_CREST` — `{{HOME_TEAM_CREST}}` | Actual crest/logo for the home team | Prefer official/project-provided SVG; raster fallback: PNG/WebP, at least 512 × 512 px | Square canvas; transparent background preferred | Typical visible crest: 72–112 CSS px depending on viewport; watermark may reuse the same asset | Typical visible crest: 52–76 CSS px; prioritize team name and time readability | Resolve dynamically from real team data; not generated |
| `AWAY_TEAM_CREST` — `{{AWAY_TEAM_CREST}}` | Actual crest/logo for the away team | Same standard as home crest: SVG preferred; raster fallback at least 512 × 512 px | Square canvas; transparent background preferred | Same optical size as home crest | Same optical size as home crest | Resolve dynamically from real team data; not generated |
| `COMPETITION_MARK` — `{{COMPETITION_MARK}}` | Competition/league emblem, if one exists in project data/assets | Existing SVG preferred; otherwise PNG/WebP, 512 × 512 px source | Square; transparent background preferred | Usually 24–40 CSS px; should remain secondary to teams and kickoff time | Usually 20–28 CSS px, or use the existing icon when space is limited | Reuse real project asset/icon; no new artwork required |
| `HOME_PLAYER_ARTWORK` — `{{HOME_PLAYER_ARTWORK}}` | Optional generated player cutout for the home team; decorative flank artwork | **Future generation target: 1024 × 1536 px PNG with alpha transparency**. An alpha-capable WebP may be used after validating the build/media pipeline | Portrait 2:3; transparent background required; full head and upper body/torso visible, preferably down to upper thigh | Render inside a responsive art layer, usually 240–420 CSS px tall; preserve aspect ratio with `object-fit: contain`; anchor toward the outer edge and avoid covering the crest, team name, or kickoff panel | Hidden by default below 640px unless a dedicated mobile composition is later approved; never force the desktop cutout into the center of the mobile layout | **Deferred. Do not generate or add now.** Resolve per team using the team artwork mapping described below |
| `AWAY_PLAYER_ARTWORK` — `{{AWAY_PLAYER_ARTWORK}}` | Optional generated player cutout for the away team; must visually pair with the home artwork | **Future generation target: 1024 × 1536 px PNG with alpha transparency**. Use exactly the same dimensions and canvas treatment as home artwork | Portrait 2:3; transparent background required; full head and upper body/torso visible, preferably down to upper thigh | Match the home artwork's displayed height, scale, light direction, contrast, and visual style; anchor to the opposite outer edge | Hidden by default below 640px unless a dedicated mobile composition is later approved | **Deferred. Do not generate or add now.** Resolve per team using the team artwork mapping described below |
| `BRAND_LOGO` — `{{BRAND_LOGO}}` | Existing SportSignal logo, only if it is included within the current Hero/header region | Reuse the existing SVG/vector or high-resolution transparent asset; do not create a replacement | Preserve source aspect ratio | Follow the existing global header specification | Follow existing mobile header behavior | Existing asset only; outside Hero redesign unless needed for layout integration |

The tokens in braces are **documentation placeholders**, not literal URLs or rendered labels. Do not print `{{...}}` into the UI or add broken `<img>` elements to imitate missing files.

## 3. Player artwork generation standard (future phase)

Generate one image for each team for which player artwork is approved. All team artwork must follow the same technical and art-direction standard so assets can be swapped dynamically without CSS changes.

### Required output

- Source canvas: **1024 × 1536 px**, portrait **2:3**.
- Format: **PNG with true alpha transparency** as the canonical deliverable. Transparent WebP is acceptable only if the app pipeline reliably preserves alpha and the visual QA passes.
- One player per image, centered on the canvas, head and shoulders fully inside the frame; preferably include torso to upper thigh when the pose allows.
- No background, stadium, typography, floating symbols, duplicate person, fake team crest, watermark, or embedded UI.
- Leave a modest transparent margin around the body; do not crop hair, shoulders, hands, or the jersey in an awkward way.
- Use consistent cinematic stadium lighting, realistic sports-editorial quality, similar contrast/sharpness, and comparable subject scale across all team images.
- **Camera direction:** the player should face the camera and make eye contact. Keep the face clearly visible and the head/shoulders mostly front-facing; avoid strict left-facing/right-facing profiles and avoid composing the subject to look toward the center of the Hero.
- **One asset, either side:** generate one canonical image for each supported team/selected representative player. The same artwork must be usable on the left or right side of the Hero. Never generate separate left-facing and right-facing variants just to match the home/away position.
- **Never mirror by default:** do not apply CSS `scaleX(-1)` or otherwise mirror the image. This can reverse shirt marks, lettering, anatomy details, or other visual cues. Place the same front-facing cutout on either side without flipping it.
- **Pose variety:** use a controlled pose library so the player artwork does not look duplicated across matchups. Example `poseId` values: `arms-crossed` (confident, calm), `hand-on-chest` (subtle badge-area gesture without requiring a visible real crest), `one-hand-raised` (restrained greeting), `hands-on-hips` (assertive stance), `fist-near-chest` (subtle celebration), and `relaxed-ready` (arms relaxed, focused expression). Vary poses between different teams and, when possible, avoid using the same `poseId` for both teams in one featured matchup. Keep gestures physically plausible and hands clearly formed; avoid complex finger-pointing or gestures likely to generate malformed hands.
- **Pose variation must not change the asset contract:** every pose uses the same 1024 × 1536 px canvas, transparent background, comparable crop and lighting family. Keep visual weight similar across poses so one side does not dominate only because its image is much larger or more tightly cropped.
- Team kit colors can inform the treatment, but any club badge or sponsor details should not be invented or rendered as fake readable text. Use approved references and the project's content policy/licensing approach when selecting a real player's likeness.
- Generate the home and away image as a **visually compatible pair** where practical: same canvas and art direction, but different poses are encouraged. Do not upscale a smaller image to pass the size check.

### Naming convention

Recommended logical path, adapted to the existing repository:

`/assets/hero/players/{team-slug}.png`

Where `{team-id}` is a stable team ID from the existing data model (preferred) or a sanitized, stable team slug—not a localized display name. Baseline contract: one approved representative-player cutout per supported team, with a pose chosen from the shared pose library. Examples below are illustrative only and are not asset requests:

- `/assets/hero/players/{home-team-id}.png`
- `/assets/hero/players/{away-team-id}.png`

Keep `poseId` metadata in the team's artwork manifest/config (for example `arms-crossed` or `hands-on-hips`) so the catalog can be audited for variety. Never create filenames from arbitrary untrusted display strings without sanitizing them. Do not hardcode a single pair of teams into the component. The goal is to support a per-team artwork lookup so any featured fixture can resolve an appropriate image when available. If the product later chooses multiple selectable players per team, the mapping may evolve to stable player IDs, but this is not required for the first artwork batch.

### Metadata/mapping contract

The eventual player-artwork integration should have an optional mapping equivalent to:

```ts
type TeamArtwork = {
  teamId: string;
  src: string;
  poseId?: "arms-crossed" | "hand-on-chest" | "one-hand-raised" |
    "hands-on-hips" | "fist-near-chest" | "relaxed-ready";
  alt?: string;
};

// Optional lookup by stable team ID. Missing values are valid.
type TeamArtworkLookup = Record<string, TeamArtwork | undefined>;
```

This snippet is illustrative only. Follow the project's actual types and naming conventions. Player artwork is decorative when the team name and crest already communicate identity; use an empty alt string or hide it from assistive technology as appropriate. If a valid asset is absent or fails to load, remove the artwork layer cleanly and let the stadium background/crest/UI occupy the composition naturally.

## 4. Responsive art-layer behavior

- Desktop (`> 900px`): optional player cutouts can occupy the outer left and right sides, typically around 18–28% of the Hero's width each, depending on the real image and current content. Keep the center kickoff panel and both crests unobstructed.
- Tablet (`641–900px`): reduce the cutout scale or disable one/both art layers if they compete with team labels and the central panel. Never compress the clock to fit artwork.
- Mobile (`<= 640px`): hide player cutouts by default in this phase's design. A future mobile-specific crop requires a separate design decision and must not harm the two-team layout.
- Use responsive CSS variables or project breakpoints, not hard-coded per-team dimensions. Every generated player image shares the same source canvas to keep this predictable.
- Artwork must not affect the height of the text/layout grid or create cumulative layout shift. Position it in a dedicated decorative layer, behind or beside content according to the accepted art direction.
- Ensure foreground text, crests, buttons, and countdown remain higher in stacking order than decorative artwork.

## 5. Background-video/image behavior

- Inspect and respect the existing media pipeline. The background can be a still stadium image or an existing loop video; this spec does not mandate one media type.
- If using video, keep it muted, inline, looped, and compliant with browser autoplay behavior; provide a poster/fallback and a reduced-motion/static alternative where appropriate.
- Do not add sound. Do not fetch videos or images from fragile third-party hotlinks.
- Background media is decorative (`aria-hidden` where appropriate) and must never be the only carrier of match information.
- Apply a local overlay/gradient as a separate layer so contrast can be tuned without destructively editing the source media.

## 6. Asset QA checklist

Before accepting a generated player image in the future phase, verify:

- [ ] Exactly 1024 × 1536 px and 2:3 ratio.
- [ ] Transparent alpha channel is present; no fake checkerboard/solid backdrop.
- [ ] One recognizable subject; no duplicate limbs/faces or malformed hands.
- [ ] Full head and intended torso crop are inside the canvas.
- [ ] No stray typography, watermark, invented readable badge, or UI.
- [ ] Lighting, scale, image quality, and visual weight are compatible with the counterpart team image.
- [ ] The player faces the camera with visible eyes and a mostly front-facing head/shoulder orientation.
- [ ] The pose is plausible, hands/anatomy are clean, and the pose differs from the opposing team's pose when practical.
- [ ] The asset is not horizontally mirrored; readable kit marks or real visual cues are not reversed.
- [ ] It remains clear over the current stadium treatment and does not reduce text contrast.
- [ ] Mobile behavior stays clean when artwork is hidden.

These sizes are the project's agreed target standard for the later image-generation stage. Do not start that stage as part of the current Hero implementation.
