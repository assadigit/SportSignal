# SportSignal Hero — Design Tokens and Components

These tokens are starting points, not permission to create a separate design system. Inspect the repository's existing design tokens and CSS variables first. Reuse or adapt the values below within the Hero scope only when they fit the existing system.

## 1. Suggested color palette

### Dark theme

| Token | Suggested value | Intended use |
|---|---|---|
| `hero-bg-base` | `#061426` | Dark Hero base or fallback |
| `hero-surface` | `#0B1D32` | Information panels |
| `hero-surface-raised` | `#102A43` | Raised cards and secondary surfaces |
| `hero-blue` | `#2868FF` | Kickoff time and primary emphasis |
| `hero-cyan` | `#27C2FF` | Restrained light lines and technical accents |
| `hero-green` | `#48EF9B` | Brand accent and countdown emphasis |
| `hero-text` | `#F4F8FF` | Primary text |
| `hero-muted` | `#A9BCD2` | Secondary text |
| `hero-border` | `rgba(126, 174, 220, .25)` | Neutral borders and separators |
| `hero-glow-blue` | `rgba(40, 104, 255, .32)` | Glow behind the kickoff time |
| `hero-glow-green` | `rgba(72, 239, 155, .18)` | Restrained secondary glow |

### Light theme

| Token | Suggested value | Intended use |
|---|---|---|
| `hero-light-bg` | `#EAF3FC` | Primary light surface |
| `hero-light-surface` | `rgba(255,255,255,.88)` | Translucent information panel |
| `hero-light-surface-soft` | `rgba(238,246,255,.88)` | Secondary light panel |
| `hero-light-text` | `#142943` | Primary text |
| `hero-light-muted` | `#4C617A` | Secondary text |
| `hero-light-border` | `rgba(29, 78, 125, .18)` | Light-theme borders |
| `hero-light-green` | `#087A48`, or an existing accessible theme token | Green text/icons on light surfaces |
| `hero-blue` | `#2868FF` | Kickoff time and primary emphasis shared across themes |

Do not use the bright green `#48EF9B` for small text on a light surface. Use a darker green for light-theme text. Neon green may remain as a decorative line or low-opacity glow.

## 2. Panels and surfaces

- The kickoff panel may use a blue gradient, a restrained bright border, and a compact shadow.
- The countdown should sit on a distinct surface with enough contrast from the background to keep every digit legible.
- Use `backdrop-filter` only if browser support and performance are acceptable. Always provide a translucent-background fallback.
- Avoid stacking multiple strong shadows, border glows, and intense gradients at the same time.
- Follow the project's existing radius tokens. If none exist, start around 12–16px for controls and 18–24px for the main container.

## 3. Typography hierarchy

- **Team names:** semibold or bold and large enough to remain readable on mobile.
- **Kickoff time:** the most prominent text value in the Hero, using a bold/black weight and `font-variant-numeric: tabular-nums` where compatible with the project's font.
- **Date:** one visual step below the kickoff time but still clear.
- **Competition and venue:** secondary information with sufficient contrast; do not reduce all metadata to tiny text.
- **Countdown labels:** compact but legible; visually distinguish each unit label from its value.
- Reuse the project's current font and type scale. Do not add a new font unless a demonstrable technical need requires it.

## 4. Suggested component responsibilities

The names below are conceptual. Follow the naming patterns already used in the repository.

### `MatchHero`

Owns the main container, background media, contrast overlay, border, theme states, and responsive layout. Use an appropriate semantic section/region and include the essential match content.

### `MatchHeroTeam`

- Inputs: team name, crest/logo, and home/away label when reliably available.
- Keep the crest's correct aspect ratio and use a bounded size.
- Allow long team names to wrap safely.
- Provide meaningful alternative text, or an empty alt when the crest is decorative because the same team name is already presented clearly next to it.

### `MatchHeroKickoff`

- Displays a prominent kickoff time.
- Displays the localized match date.
- Must not contain hardcoded match data.

### `MatchCountdown`

- Receives a valid authoritative kickoff timestamp.
- Displays days/hours/minutes/seconds using locale-compatible digits and labels.
- Cleans up intervals/timers on unmount.
- Never displays a negative countdown for a past kickoff.
- For live or finished matches, shows status-specific content instead of a future countdown.

### `MatchMeta`

Displays competition, venue, and useful secondary information chips. Do not render fields for which valid data is unavailable.

### `AthleteArtworkSlot` (optional future capability)

Do not create a visible player-art component as part of the current task. If supporting future artwork is useful, expose it as a small optional prop/slot with no default asset. If artwork is absent, the Hero must remain visually complete without a conspicuous gap or awkward placeholder. Player images must not be generated or downloaded in this phase.

## 5. Match-status color semantics

- **Brand green:** neutral/positive emphasis and countdown; do not use it to imply a live match by default.
- **Red:** reserve for an actual live state or alert only when consistent with the existing design system. Do not use persistent red flashing for upcoming fixtures.
- **Blue:** kickoff time and primary focus.
- Status must be communicated with text and/or an icon as well as color; color alone is insufficient.

## 6. Icons

- Inspect the icon library already used by the project first.
- Do not add another icon package just for the Hero when the existing library is sufficient.
- Do not use emoji as the primary UI icon system unless the rest of the site already uses emoji that way.
- Mark decorative icons with `aria-hidden="true"`. Interactive icon-only controls must have accessible names.
