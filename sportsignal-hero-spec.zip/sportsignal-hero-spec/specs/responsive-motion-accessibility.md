# SportSignal Hero — Responsive Behavior, Motion, Accessibility, and Performance

## 1. Breakpoint strategy

Use the breakpoints already established by the project. If no responsive system exists, the ranges below are initial guidance only. Final breakpoints should be determined by actual content fit rather than device labels.

- `<= 360px`: very narrow mobile; shorten secondary metadata, reduce decoration, and preserve a readable kickoff time.
- `361–640px`: mobile; place teams in two columns and the kickoff/countdown area underneath.
- `641–900px`: tablet or medium viewport; the layout may approach a compact desktop composition, but teams and time must not become cramped.
- `> 900px`: desktop; use a three-zone grid with teams on either side and kickoff information in the center.

Do not apply these values blindly. Align final breakpoints with real content widths and the repository's current CSS conventions.

## 2. Viewport verification

At minimum, test these viewport widths:

- 320px
- 360px
- 390px
- 430px
- 768px
- 1024px
- 1280px
- 1440px
- 1920px, if supported by the site's wide layout

At common widths, the Hero must not have horizontal scrolling or clipped text.

## 3. Motion system

### Ambient glow

- Suggested cycle: 8–12 seconds.
- Keep opacity and scale changes subtle.
- Animate only a pseudo-element or decorative layer so the main content does not repeatedly repaint or reflow.
- Use lower intensity and softer glow colors in light mode.

### Hover and focus

- Apply hover effects only to genuinely interactive elements.
- Typical transition duration: 150–220ms.
- Hover must not change the overall Hero size or move neighboring layout elements.
- Do not create sticky or unpredictable hover behavior on touch devices.

### Countdown

- Update only the time values each second.
- Do not flash or pulse the entire Hero every second.
- Avoid large width changes as digits update; use tabular numerals or minimum widths where appropriate.

### `prefers-reduced-motion`

When the user requests reduced motion:

- Stop ambient animation or replace it with a static state.
- Remove unnecessary hover transforms.
- Minimize transitions.
- Keep all information and functionality available.

## 4. Performance

- Avoid adding dependencies without a concrete need.
- If video is used, keep it silent and configure `muted`, `playsInline`, and `loop` in accordance with browser autoplay policy. Provide an appropriate poster/fallback. If no project video is used, prefer an optimized local image with suitable dimensions.
- Check the size and format of background assets; do not add a large, unoptimized image to the bundle.
- Provide suitable image dimensions and loading behavior to reduce layout shift.
- Avoid expensive filters over large areas and persistent animated `backdrop-filter` effects.
- If the current API/data model already provides the needed match information, do not add another request or polling loop solely for the Hero.
- Clean up countdown intervals/timers on unmount. If the app already has a shared clock/hook pattern, prefer it.

## 5. Accessibility

- Text over overlays and panels must remain readable; target at least WCAG AA contrast for normal text.
- Do not distinguish time and date using color alone.
- Provide visible `focus-visible` states for keyboard-accessible controls.
- Only genuinely interactive elements should use interactive semantics. Do not use a clickable `div` without appropriate role and keyboard support.
- Hide decorative background media from screen readers where appropriate.
- Team crest alt text should be meaningful unless the team name is already clearly shown and the crest is only redundant decoration.
- Avoid rapid flashes or intense light patterns.
- Keep DOM content order logical for RTL and screen readers. Do not rely solely on CSS visual reordering unless the accessible reading order remains correct.

## 6. Theme and locale behavior

- Preserve the site's existing theme and locale selection systems; do not create conflicting state.
- If the theme is set before mount, avoid introducing a flash between themes.
- Respect direction and bidirectional text behavior in RTL/LTR. Separate time/digit blocks from Persian text direction where needed.
- Test long English strings as well as Persian text on narrow viewports. Responsive behavior must not work only for short Persian labels.
