# SportSignal Hero — Implementation Guide and Acceptance Criteria

## 1. Phase zero: inspect the repository

Before changing code, the agent must:

1. Read repository guidance files, package manifests, and the application structure.
2. Identify the framework, router, and homepage route.
3. Locate the current Hero component and its relevant parent components/layouts.
4. Trace the match data model, featured-match selection, kickoff timestamp, match status, and timezone.
5. Inspect the existing dark/light theme system, language/i18n, fonts, icon library, and design tokens.
6. Inventory current stadium, team-crest, and background assets.
7. Identify existing test, lint, type-check, and build commands.

Use the existing architecture as the baseline. Do not make unnecessary changes during inspection.

## 2. Implementation strategy

- First, incrementally redesign only the current Hero.
- Reuse existing data fetching, featured-match selection, and utility functions wherever possible.
- Do not build a large parallel CSS system next to the site's design system.
- If the project uses React, Vue, Svelte, Next.js, or another framework, follow its existing patterns. Do not change frameworks.
- Reuse existing team-crest, countdown, theme, and i18n components if available.
- Do not move sample values from mockups into production logic.
- If a field such as venue is not available in current data, treat it as optional. Do not build a new API or display invented content.
- Any newly selected background asset must be local, approved for use in the project, and have a fallback. Do not use unknown or temporary image URLs.
- Do not create, download, or otherwise supply bespoke player images in this phase.

## 3. Data and countdown logic

- Get the actual kickoff timestamp and correct timezone from the existing data model.
- The displayed kickoff time and countdown must use the same authoritative time reference.
- Do not use hardcoded dates/times, decorative timers, or negative countdowns.
- If the match status indicates live, finished, postponed, or cancelled, render the appropriate status UI.
- If status is unknown or the timestamp is missing, show only trustworthy information and hide the countdown.
- When the featured match changes, the timer and displayed content must update to match it.
- Verify timer cleanup and, if applicable, SSR/hydration safety and prevention of time-related mismatches.

## 4. Scope constraints

- Do not broadly redesign unrelated page sections or core site logic.
- Change the API, schema, or data source only if absolutely necessary, and document the reason in the final report.
- Do not add a new animation, carousel, or icon library unless the existing project cannot meet the requirement.
- Do not change secrets, tokens, or environment configuration.
- Do not create player assets.
- If the design conflicts with the repository's architecture, adapt it to the existing code and explain the deviation. Do not stop for non-blocking questions; use sound engineering judgment.

## 5. Design acceptance criteria

### Visual quality

- [ ] The Hero feels cinematic and sports-focused, with restrained HUD details.
- [ ] Kickoff time is the primary information focal point.
- [ ] Both teams and their crests are balanced and readable.
- [ ] Competition, date, and countdown have a clear hierarchy.
- [ ] Glows are restrained and do not hurt text legibility.
- [ ] No fabricated player images or unrelated placeholder images have been added.

### Data and behavior

- [ ] The Hero uses the real featured match from the existing project.
- [ ] Time and date are accurate and localized.
- [ ] Countdown is calculated from the authoritative kickoff timestamp.
- [ ] Relevant match statuses are handled; a future countdown is not shown for live or finished matches.
- [ ] Any CTA has a real action and destination.

### Responsiveness

- [ ] The implementation has been tested at 320, 360, 390, 430, 768, 1024, 1280, and 1440px.
- [ ] Both teams, kickoff time, and countdown remain clear on mobile without overflow.
- [ ] No unwanted fixed-height clipping occurs.
- [ ] Persian RTL and English LTR behavior have been checked when both locales are supported.

### Themes and accessibility

- [ ] Dark mode uses bright text, a deep background, and controlled lighting.
- [ ] Light mode has its own bright design and is neither dull nor low contrast.
- [ ] Motion respects `prefers-reduced-motion`.
- [ ] Focus states and semantics are appropriate.
- [ ] Image alt/fallback behavior is suitable for each asset.

### Engineering quality

- [ ] Existing lint/test/build checks have been run and their outcomes reported.
- [ ] No important new console error or hydration warning is introduced.
- [ ] No unnecessary dependency is added.
- [ ] Timer/interval cleanup is correct.
- [ ] Changes remain focused on the Hero and do not regress unrelated areas.

## 6. Required final report from the agent

The completion report must state:

1. Which files changed and what was implemented.
2. Key design and technical decisions.
3. How the countdown and match statuses use real project data.
4. Which test/lint/build commands were run and their results.
5. Which items could not be completed due to missing assets or data.
6. Explicit confirmation that player artwork was intentionally deferred and no player images were generated or added.
