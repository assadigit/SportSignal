# SportSignal — Hero Redesign Specification

This package defines the design direction, implementation constraints, asset contracts, and acceptance criteria for the SportSignal homepage Hero. The approved direction is **Stadium Pulse + Match Protocol**: a cinematic, energetic, readable, responsive football experience that combines sports-broadcast atmosphere with restrained gaming/eSports details.

## Confirmed decisions

- [x] Visual style: sports broadcast plus controlled gaming/eSports details; avoid visual clutter.
- [x] Goals: create excitement, make match information scannable, strengthen brand identity, and encourage repeat visits.
- [x] Focus the Hero on one real featured match.
- [x] Use a responsive mobile composition, not merely a scaled-down desktop layout.
- [x] Design both dark and light themes intentionally.
- [x] Use medium-to-high but purposeful motion, with performance and reduced-motion support.
- [x] The stadium background may be redesigned. The existing stadium video or still image is not a mandatory dependency.
- [x] Player artwork is deferred to a later phase and must not be generated during the current implementation.
- [x] Every image slot has a documented placeholder, suggested asset path, source format, source dimensions, aspect ratio, responsive behavior, and implementation guidance in `specs/image-assets-and-placeholders.md`.
- [x] The future player-artwork contract uses one front-facing image per selected representative player/team, with a varied pose library. Separate left-facing/right-facing variants and automatic image mirroring are not required.

## Package contents

- `specs/hero-redesign-spec.md` — product goals, Hero structure, information hierarchy, match states, and visual behavior.
- `specs/design-tokens-and-components.md` — suggested color tokens, typography, surfaces, and component responsibilities.
- `specs/responsive-motion-accessibility.md` — responsive strategy, motion behavior, accessibility, and performance constraints.
- `specs/image-assets-and-placeholders.md` — asset manifest, image placeholders, target dimensions, and future player-artwork contract.
- `specs/implementation-and-acceptance.md` — repository inspection strategy, implementation scope, and acceptance checklist.
- `assets/hero/players/README.md` — reserved directory contract for future player artwork.
- `AGENT_IMPLEMENTATION_PROMPT.md` — ready-to-use English prompt for a coding agent.

## How to use this package

1. Add the `sportsignal-hero-spec` directory to the repository root or your preferred documentation location.
2. Give the coding agent the contents of `AGENT_IMPLEMENTATION_PROMPT.md`.
3. Ask the agent to inspect the existing project before modifying it, then implement the Hero directly in the application.
4. Do not generate player images yet. The target dimensions, placeholders, naming convention, and pose library are defined for the later artwork phase.

## Implementation principle

These documents describe the desired design; they do not assume a particular framework or application architecture. Before making changes, the agent must inspect the repository, theme system, localization, match data, and existing assets, then follow current project conventions. Documentation placeholders must never appear as literal text or broken images in the production UI.
