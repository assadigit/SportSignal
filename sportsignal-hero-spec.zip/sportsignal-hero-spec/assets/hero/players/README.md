# Future Hero Player Artwork Directory

This directory is reserved for future generated player cutouts. **Do not add or generate player images during the current Hero implementation task.**

When the artwork phase is approved, create one canonical transparent PNG for each supported team, depicting one approved representative player from that team. The selected player should face the camera, with a clearly visible face and a mostly front-facing upper body. Each team's artwork may use a different confident, natural pose from the shared pose library in `../../../specs/image-assets-and-placeholders.md`.

- Source canvas: **1024 × 1536 px** (portrait 2:3)
- Format: PNG with true alpha transparency
- One player, no background, no UI, no watermark, and no invented readable badge/sponsor text
- Same cinematic art direction, lighting family, subject scale, and crop across the catalog
- Different `poseId` values across teams when practical; avoid identical poses for both teams in a featured matchup where possible
- **Do not create left-facing/right-facing variants and do not mirror the image in CSS.** The same front-facing artwork can be placed on either side of the Hero.
- Stable filename based on team ID, e.g. `{team-id}.png`; store `poseId` in the artwork manifest/config

The runtime path can be changed to match the app's actual asset pipeline. This directory documents the future convention; the application must not assume the files exist yet.
