# Coding Agent Prompt — SportSignal Hero Redesign

You are working in the existing SportSignal repository. Before making any changes, read every document in this specification package and treat it as the source of truth for this task:

- `README.md`
- `specs/hero-redesign-spec.md`
- `specs/design-tokens-and-components.md`
- `specs/responsive-motion-accessibility.md`
- `specs/image-assets-and-placeholders.md`
- `specs/implementation-and-acceptance.md`

## Mission

Redesign and implement the production Hero for the featured football match using the **Stadium Pulse + Match Protocol** direction: cinematic stadium atmosphere, controlled blue/green lighting, restrained HUD details, a prominent kickoff time, local match date, and a real countdown when the match is upcoming. The result must be fully responsive and intentionally designed for both dark and light themes.

This is an implementation task in the existing product—not a request for a standalone mockup or an isolated demo.

## First inspect the repository

1. Identify the framework, app entry point, home page route, existing Hero component, parent layout, styling approach, design tokens, fonts, icons, theme handling, localization/i18n, and test/build scripts.
2. Trace the existing match data model, featured-match selection logic, team IDs/slugs, crest URLs, competition, venue, kickoff timestamp, timezone, and match status.
3. Inventory existing stadium media and other relevant assets. Reuse suitable local assets and existing project conventions where possible. Do not add fragile third-party hotlinks.
4. Do not replace the framework, rewrite the design system, alter data fetching, or refactor unrelated parts of the site without a concrete technical reason.

## Required implementation

- Keep the Hero connected to the real featured match selected by the existing product logic. Do not hardcode the example teams, dates, kickoff times, countdown values, venue, or status shown in mockups.
- Display the home team and away team with their actual crests, a prominent kickoff time, correctly localized date, competition, and venue only when valid data exists.
- Implement a real countdown from the match's authoritative kickoff timestamp. Clean up timers on unmount and when the featured match changes. Do not show a future countdown for live, finished, postponed, or cancelled matches. Render statuses only when supported by real data.
- Create a responsive desktop composition with the two teams flanking the time/date area, and an independent mobile layout. Verify that viewport widths from 320px upward do not produce horizontal overflow.
- Implement coherent dark and light themes. Light mode must have its own bright, high-contrast treatment rather than a simple color inversion.
- Use CSS for restrained ambient glow, border lighting, and interaction states. Respect `prefers-reduced-motion`. The countdown must not make the entire card pulse or reflow every second.
- Preserve existing RTL Persian behavior and English LTR behavior if the project supports both. Use the existing localization and font systems.
- Existing CTA controls may be retained only if they have a real destination/action. Do not add inert buttons.
- Prefer current components, icon libraries, tokens, team-crest sources, and utilities. Avoid unnecessary dependencies.

## Image slots and future player artwork

Read `specs/image-assets-and-placeholders.md` carefully. It defines the asset slots, filename conventions, required source dimensions, aspect ratios, transparency, responsive display sizes, and future player-artwork contract.

**Do not generate, download, or fabricate any player images in this task.** Player artwork is explicitly deferred. Do not use unrelated footballers, stock images, broken image URLs, or visible blank frames. The Hero must look finished without player artwork. Structure the code so artwork can be enabled later through an optional team-artwork mapping/prop, with a graceful fallback when a team has no mapped asset. Do not show an empty artwork slot or reserve a conspicuous blank space. Do not require artwork to render the Hero.

Do not create fake player assets merely to satisfy the placeholder paths. The specified filenames and dimensions are a future asset contract, not a request to add the actual files now. Existing team crests and the actual stadium media are separate assets and should continue to use the project's real sources.

## Implementation process

1. Read all specification files and inspect the repository before editing.
2. Identify the smallest set of relevant files to change.
3. Implement the redesigned Hero in the existing application architecture.
4. Run available formatting, lint, type-check, tests, and production build commands where practical.
5. Test at widths 320, 360, 390, 430, 768, 1024, 1280, and 1440px (and 1920px if supported). Check Persian RTL, English LTR when available, both themes, missing optional fields, and match status changes.
6. Fix new overflow, clipping, contrast, accessibility, timer cleanup, hydration, and console issues.
7. Review every acceptance item in `specs/implementation-and-acceptance.md` before finishing.

## Scope and decision-making

- Keep the change focused on the Hero and essential supporting styles/components.
- Do not add a new API, scraper, data source, or polling loop just for this design.
- Do not generate player images in this phase.
- If a detail conflicts with the repository architecture, adapt it to the existing codebase and explain the deviation in the final report. Do not stop for non-blocking questions; use sound engineering judgment.
- Do not reformat or rewrite unrelated files.

## Final report

At completion, report:

1. Which files changed and what was implemented.
2. Important UI/UX and technical decisions.
3. How the countdown and match statuses use real project data.
4. Which lint, type-check, tests, and build commands ran, with their results. Clearly state any checks you could not run.
5. Responsive/theme/RTL checks performed and known limitations.
6. Explicit confirmation that player artwork was **not** generated or added and remains a later task.

Now read the specification files, inspect the existing repository, and implement the Hero directly in the project.
