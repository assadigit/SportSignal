<!-- agent-instructions.md — one-time task list: restyle the SportSignal featured-match hero to match desired-look.jpg.
     Paste/point your coding agent at this file. It reads tokens.css and design.md, then does every step itself. -->
# Task: restyle the featured-match hero to match `desired-look.jpg` (target) from `4.png` (current)

## Step 0 — Orient yourself (do this automatically)
1. Put `tokens.css` and `design.md` into the project (global stylesheet folder / project context). Import `tokens.css` once, before the hero styles.
2. Find the hero component by searching the codebase for the strings `ساعت شروع`, `تا بازی بزرگ بعدی`, `ورزشگاه`, `لیگ قهرمانان اروپا` (Farsi) or `Kickoff`, `Until the next big match`, `Parc des Princes`, `Champions League` (English). Edit only that component, its stylesheet, and the header if needed.
3. Do NOT change data, routing, countdown logic, language switch, theme switch or RTL direction. Visual layer only. Keep the existing text strings and real data (teams, host/guest, time, date, venue). The hero exists in two languages: Farsi (RTL) and English (LTR). Every rule below applies to both. Where a rule says left/right, think "home side" / "away side" and use CSS logical properties (`inline-start`/`inline-end`) so the layout mirrors correctly; do not swap which player sits on which side.
4. Open `desired-look.jpg` and `4.png` and compare against them after each priority group.

## P1 — Structure (layout)
1. KEEP the card (it is a deliberate design choice: players break out of it for a 3D effect). Do not remove it and do not set `overflow: hidden` on it in a way that clips the players. Restyle it only: `min-height: var(--ss-hero-min-h)`, keep the rounded corners, replace the border with a 1px `--ss-glass-border` hairline, remove the corner brackets, and let the stadium background (P3) fill it completely.
2. Keep the header where it is (above the card, so the players have room to pop out). Only restyle the controls (moon / EN / gear): one dark-glass rounded container using `--ss-glass-bg` and `--ss-glass-border`.
3. Move the "آخرین به‌روزرسانی" line out of the hero: render it as small muted text (`--ss-text-muted`, ~12px) directly under the hero, centered.
4. Center column, top to bottom, all centered on the page midpoint, stacked with ~14–18px gaps:
   a. Champions League icon (~40px) then the league title "لیگ قهرمانان اروپا" in `--ss-text-label`, bold, ~18px. Delete the separate league chip.
   b. Time chip (see P2.1).
   c. Date line "سه‌شنبه ۲۸ مهر", white, ~16px, bold. Put "به وقت تهران" in `--ss-text-muted` ~12px after the date on the same line (keep it; users need the time zone).
   d. Venue pill (see P2.3).
   e. Countdown panel (see P2.4).
5. Team blocks flank the time chip at the same vertical centre as the chip: crest `--ss-crest-size` (~82px), team name white bold ~20px, and the host/guest label under the name in `--ss-aqua` ~13px. Barcelona block on the left, PSG block on the right (keep current host/guest data; only the visual changes). Delete the old "ساعت شروع" label above the time.
6. Bottom-left: small glass pill carousel with the two team crests (~22px), pager dots, and prev/next chevrons. If the hero shows only one match, render it as static (non-functional dots) only if a matches list already exists; otherwise skip it.
7. Bottom-right: glass pill button "بازی‌های آینده را ببینید" with a bell icon, aqua text, `--ss-glow-cyan` on hover. Link it to the existing upcoming-matches page/route in the project; if none exists, link to the matches section already on the page.

## P2 — Components
1. Time chip: size `--ss-time-w` × `--ss-time-h`. Chamfered hexagon via `clip-path: polygon(var(--ss-time-chamfer) 0, calc(100% - var(--ss-time-chamfer)) 0, 100% 50%, calc(100% - var(--ss-time-chamfer)) 100%, var(--ss-time-chamfer) 100%, 0 50%)`. Fill: `linear-gradient(180deg, #124693 0%, #02266D 100%)`. A clip-path cuts borders, so draw the cyan border with a wrapper element (same clip-path, background `--ss-cyan`, 2px larger) behind the fill, plus `filter: drop-shadow(0 0 14px rgba(0,211,255,.5))` on the wrapper. Time text: white, weight 800, ~38px, tabular numerals; small clock icon (~26px, white face, cyan ring) placed on the right of the digits (RTL).
2. Replace the current flat solid `#2E68F8` card entirely (also remove its rounded rectangle shape and drop shadow).
3. Venue pill: height ~34px, `--ss-radius-pill`, background `--ss-glass-bg`, 1px border `--ss-glass-border`, white text ~14px, small stadium icon on the right.
4. Countdown panel: width `--ss-countdown-w`, height ~`--ss-countdown-h`, radius `--ss-radius-panel`, background `--ss-glass-bg`, `backdrop-filter: blur(var(--ss-glass-blur))`, 1px border in a cyan→aqua gradient plus `--ss-glow-cyan`. Header row centered: timer icon (`--ss-green`) + text "تا بازی بزرگ بعدی" in `--ss-green`, ~14px. Below it, 4 equal tiles in one row (روز، ساعت، دقیقه، ثانیه — order follows RTL: days on the right). Each tile: radius `--ss-radius-tile`, 1px `--ss-glass-border`, background `--ss-glass-bg-soft`, number white weight 800 ~28px tabular, label `--ss-aqua` ~12px. Replace the colon-separated single-row look, the green `#48EF9B` digits and the yellow lightning icon.
5. Controls group and venue/countdown/carousel/button all share the same glass recipe: bg + 1px glass border + blur.

## P3 — Background, light and depth
1. Background layers (bottom to top), all on the hero element:
   a. Stadium night photo (see ASSETS) covering the hero, `object-fit: cover`, centered.
   b. Colour grade: `linear-gradient(180deg, rgba(1,10,29,.55) 0%, rgba(1,20,48,.25) 45%, rgba(1,10,29,.75) 100%)`.
   c. Side vignette: radial-gradient darkening to `--ss-bg-abyss` at left/right edges.
   d. Floodlight glow top-left and top-right: two `radial-gradient(circle at 12% 0%, rgba(120,190,255,.55), transparent 35%)` style highlights (mirror the second at 88% 0%).
   e. Centre scrim behind the info column: `radial-gradient(ellipse at 50% 55%, rgba(1,10,29,.55), transparent 60%)` so white text stays readable.
2. Light streaks bottom-left (blue `--ss-blue`) and bottom-right (green `--ss-green` blending to blue): two SVG swoosh shapes, absolutely positioned at the bottom corners, 2–3 curved bands each with `mix-blend-mode: screen`, thin bright edge line, soft glow. Draw them yourself as inline SVG (no external file needed).
3. Faded club-crest watermarks: Barcelona crest large (~380px) behind the left player, PSG crest large behind the right player, opacity ~0.14, slightly blurred, partially cut by the edge.

## P4 — Players (KEEP the 3D pop-out and the front-facing photos)
1. Keep the current approach: each player is a transparent cut-out that extends OUTSIDE the card (above its top edge and/or past its side edges) while the lower body stays inside the card. Implement it with a clipping wrapper or `clip-path` that cuts only the bottom edge (and sides if the current build does that), never the top. Do not shrink, flip or re-crop them.
2. Make them larger and closer to the reference's scale: roughly 90–100% of card height plus the part that pops out, anchored to the bottom, left player at the left edge, right player at the right edge. Keep them behind the center info column (z-index) and above the background and watermarks.
3. Match the reference's lighting on the existing front-facing photos: rim light `filter: var(--ss-player-glow)` (cyan glow in dark mode, soft dark drop-shadow in light mode — a cyan glow looks like a halo on the pale page), a slight blue color grade (`brightness(.95) contrast(1.05)`), and a soft bottom fade into the dark so the body melts into the card edge.
4. To get some of the "facing each other" feeling without new photos: place each player so their body leans a few degrees toward the center (`transform: rotate(-2deg)` on the left, `rotate(2deg)` on the right, no mirroring), and put the watermark crest directly behind each.
5. Do not mirror images that contain kit text or crests.

## P5 — Responsive and quality
1. Below 900px: hide the watermarks and swooshes' secondary bands, stack the center column over a single centered player pair scaled to ~60% hero height; countdown panel width 92%; hide carousel pill, keep bell button.
2. Keep `dir=rtl` behavior unchanged. Respect `prefers-reduced-motion` (disable glow pulse).
3. Keep contrast: white text on glass ≥ 4.5:1.
4. Run the project's build/lint and fix any errors you introduced.
5. Final check: render the hero at 1522×463 and 1445px widths, compare side by side with `desired-look.jpg`, and fix any visible mismatch (gap sizes, glow strength, player scale). Report a Match/Mismatch list at the end.

## ASSETS (agent: handle these yourself, with the fallbacks)
| Slot | What it needs | Source order |
|---|---|---|
| Stadium background | Night stadium, floodlights top corners, crowd + pitch at bottom, dark blue, ≥1920×700, no visible club branding/ads. | 1) existing background already used by the hero (grade it with P3). 2) If the project has none, build a CSS-only stadium-night background (gradients + two floodlight glows + blurred dots for crowd bokeh) so nothing blocks the build. |
| Left & right player cut-outs | Transparent PNG/WebP, front-facing is fine (deliberate choice), torso up, ~1200px tall, good resolution for the pop-out. | Use the current files. No new assets required. |
| Club crests | Transparent PNG/SVG, 512px+. | Use the crests already shown in the current hero. |
| Champions League icon | Small ball-star icon, ~80px, white/blue on transparent. | Use the one already on the site if present; otherwise a neutral football/ball icon from the project's icon set. |
| Icons | clock, stadium, timer, bell, chevrons | Project's existing icon set (e.g. lucide) — no new dependency. |
| Swooshes | Light streaks | Inline SVG you draw (P3.2). |

## P6 — Light mode (hero stays dark; page around it turns light)
Decision: the hero card keeps the same dark "stadium night" look in BOTH themes. Only the page chrome around it changes. Do not build a separate light version of the hero.
1. Find how the site switches theme (look at the moon button handler: `data-theme`, a `.light`/`.dark` class, or a CSS media query). Make `tokens.css`'s light block match that exact mechanism by changing its selector.
2. Remove everything that currently washes out the hero in light mode: the white/pale overlay, white haze on the background, reduced opacity of the stadium photo, and the pale tint on the watermark crests. The hero must look identical to dark mode except for the lifted navy values in `tokens.css`.
3. Hero card in light mode: add `box-shadow: var(--ss-hero-shadow)` so it floats above the pale page. Keep the hairline `--ss-glass-border`.
4. Everything inside the hero uses the hero tokens only (white text, aqua labels, glass tiles). Delete the light-mode versions of the time card (flat blue), the white countdown pill with green digits, and the gray labels (host/guest, league chip, venue pill). They must be the same glass components as dark mode.
5. Everything outside the hero (page background, header logo/nav text, the "last updated" line, cards below the hero) uses `--ss-page-bg`, `--ss-page-ink`, `--ss-page-ink-muted`, `--ss-page-surface`, `--ss-page-border`. The header controls (moon / EN / gear) in light mode: white surface, 1px `--ss-page-border`, ink icons; in dark mode keep the dark glass.
6. The "last updated" line sits outside the hero, so it uses `--ss-page-ink-muted` in both themes.
7. Players popping out above the card in light mode use `--ss-player-glow` (soft dark shadow). Check their cut-out edges on the pale background: if any light fringe or halo shows, add `filter: drop-shadow(0 0 1px rgba(8,32,63,.6))` first in the filter list.
8. Check both themes at 1445px and 1522px wide against `desired-look.jpg` and `1.png` (the old light look); report a Match/Mismatch list.

## P7 — HARD RULE: players must never touch or cover a club name (safe padding)
Reason: with a long club name (example: "Paris Saint-Germain FC") the name currently runs underneath the player photo. This must be impossible by construction, for every club, both languages, both themes, every width.

1. Build the hero row as a 5-lane CSS grid, one row, using logical order: `[player lane] [team lane] [center column] [team lane] [player lane]`. Suggested columns at desktop: `minmax(0, 22%) minmax(0, 1fr) minmax(240px, 30%) minmax(0, 1fr) minmax(0, 22%)`. Each team block (crest + name + host/guest label) lives only in its team lane. Each player image lives only in its player lane.
2. Safe padding: the player image's inner (center-facing) edge must stay at least `--ss-safe-gap` = 24px away from the team lane's content box at all times. Add `--ss-safe-gap: 24px;` to `:root` in `tokens.css` and use it as `padding-inline` on the team lane facing the player and as the gap between lanes.
3. The 3D pop-out may only go UP (above the card top) and OUTWARD (toward the card's own side edge). It must never extend INWARD into the team lane. Implementation: put each player in a wrapper that is exactly its lane's width, and clip only the inward edge and the bottom of that wrapper. For the player on the physical LEFT use `clip-path: inset(-100% 0 0 -100%)` (top and outer-left stay open, inward-right is cut at the lane edge, bottom is cut at the card edge); for the player on the physical RIGHT use `clip-path: inset(-100% -100% 0 0)`. The home club sits on the left in English (LTR) and on the right in Farsi (RTL), and each player always stays with his own club. So apply the two clip-paths by the player's CURRENT physical side: write them once per direction (`[dir="ltr"] .home-player` / `.away-player` and `[dir="rtl"] ...`) or use logical-aware custom properties, and verify in both languages. Inside the wrapper the image uses `max-width: 100%`, `object-fit: contain`, `object-position: bottom` toward its outer edge.
4. Team names must fit their lane without touching anything:
   - `max-width: 100%`, `overflow-wrap: anywhere`, `text-wrap: balance`, allow up to 2 lines (`-webkit-line-clamp: 2`), centered.
   - Font size: `clamp(15px, 1.35vw, 20px)`.
   - The crest stays above the name, centered in the lane (as in the reference), never overlapping the player.
   - If a name still needs more than 2 lines at the smallest size, use the project's existing short name/abbreviation field for that team if one exists. Do not change the real data otherwise.
5. When space gets tight (narrower screens), shrink in this order, and never break the safe gap: (a) reduce player scale, (b) reduce player lane width to as low as 16%, (c) reduce name font size to the clamp minimum, (d) below 900px, switch to the stacked mobile layout from P5 where players move behind the lower corners and team names sit in their own row.
6. Automatic verification (the agent must write and run this itself; do not skip): add a Playwright (or the project's existing browser-test) script `tests/hero-safe-padding.spec` that, for each combination of language (English, Farsi), theme (light, dark), viewport width (1522, 1445, 1280, 1024, 900) and these test club names — "Paris Saint-Germain FC", "Borussia Mönchengladbach", "Brighton & Hove Albion", "پاری سن ژرمن", "منچستر یونایتد" — sets the team names, then measures `getBoundingClientRect()` of each team name, crest and player image, and fails if:
   - any player rect overlaps any team-name or crest rect, or
   - the horizontal gap between a player rect and the nearest name rect is less than 24px, or
   - a name's `scrollWidth` exceeds its `clientWidth`.
   Fix the layout until the test passes, then keep the test in the repo.
7. Add the same rule to the project's standing agent context file (`CLAUDE.md` / `.cursorrules` / `AGENTS.md`, whichever exists; create `CLAUDE.md` if none): "In the featured-match hero, player images must never overlap or come closer than 24px to a club name or crest. See design.md → Safe padding. Run hero-safe-padding test before finishing any change to the hero."
