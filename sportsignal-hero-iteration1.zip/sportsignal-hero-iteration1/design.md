<!-- design.md — standing rulebook for the SportSignal "stadium night" hero style.
     Keep this where your coding agent reads project context (project root, docs/, or CLAUDE.md). Tokens live in tokens.css. -->
# SportSignal hero — "Stadium Night" rulebook

## Core principles
1. One cinematic scene inside a card with a hairline cyan border; players break out of the card for a 3D effect (deliberate).
2. Two large front-facing players flank the centre; the match info is a stacked column in the exact middle.
3. Everything interactive is dark glass with a thin cyan hairline and a soft cyan glow — never flat solid blue.
4. Colour roles are fixed: navy = depth, cyan/aqua = information accents, blue = light streaks, green = one neon streak.
5. Light comes from the top corners (floodlights); edges vignette to near-black.

## Safe padding (hard rule)
- Player images must never overlap, cover or come within `--ss-safe-gap` (24px) of a club name or club crest, for any club name length, in any language, theme or width.
- Layout is lane-based: player lane, team lane, centre column. A player never enters a team lane; the 3D pop-out goes only upward and outward.
- Long names wrap (max 2 lines) and scale down before anything is allowed to touch.

## Do
- Use `--ss-cyan` for the time-chip border and `--ss-aqua` for the small host/guest labels.
- Give the time a chamfered (cut-corner) hexagon shape using clip-path with `--ss-time-chamfer`.
- Use separate bordered tiles for the countdown numbers (one per unit), not one long pill.
- Keep text white; only labels (host/guest, countdown units, league title) use cyan tones.
- Put huge faded club crests behind each player as watermarks (opacity 0.12–0.2).
- Let players overflow the card's top and sides (3D pop-out) and crop at the bottom; do not shrink them.

## Don't
- Don't use the flat `#2E68F8` blue card, a yellow lightning icon, or green digits (current look).
- Don't clip the players' heads inside the card; the pop-out is intentional.
- Don't let a player image extend inward over a club name or crest; never rely on a short club name to avoid a collision.
- Don't put the "last updated" line on top of the hero image.
- Don't mirror (flip) player images that contain kit text or crests.
- Don't add new hues beyond the tokens.

## Component states (rest state only is visible in the reference)
- Hover/focus for glass pills and tiles: raise border to `--ss-aqua` and glow to full strength; do not introduce a new hue.
- Keep a visible focus ring (2px `--ss-aqua`, offset 2px) on the "upcoming matches" button and carousel arrows.
- Not observed: disabled, loading, error. Default: same glass surface at 50% opacity, no glow.

## Motion (recommended, not observed)
- Countdown tick: no animation on digits except a 150ms fade. Glow pulse on the time chip, 3s ease-in-out, subtle. Respect `prefers-reduced-motion`.

## Accessibility constraints
- White text on glass must stay ≥ 4.5:1 against the actual image behind it; keep the scrim gradient in place under the centre column.
- Countdown units need text labels (not colour alone).

## Extending the system
New pill → glass bg + 1px glass border + `--ss-radius-pill`. New tile → `--ss-radius-tile`. New accent text → aqua or cyan only.

## Light mode
- The hero card is a dark island in both themes; never build a pale/washed version of it.
- Page chrome outside the hero uses the `--ss-page-*` tokens; keep body text at or above 4.5:1 (ink `#0B1B33` on `#EEF4FA` is 15.5:1, muted `#3B506B` is 7.4:1).
- In light mode, replace the cyan player glow with a soft dark drop-shadow; a cyan halo reads as a defect on a pale page.
