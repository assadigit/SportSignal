Football league square icons — 1024 × 1024 PNG

Files:
- premier_league.png
- laliga.png
- serie_a.png
- bundesliga.png
- ligue_1.png

The images are clean, watermark-free high-resolution re-creations for Telegram bot use. They are not official vector downloads, so small details may differ from official league artwork. The BUNDESLIGA wordmark has been kept visible.

References consulted for identity matching:
- Premier League logo guidance: https://logo.premierleague.com/
- LaLiga official logo page: https://www.laliga.com/en-BR/pressroom/logos-and-corporate-dossier/logos
- Serie A logo reference: https://commons.wikimedia.org/wiki/File:Serie_A_logo_2022.svg
- Bundesliga logo reference: https://www.footylogos.com/logos/bundesliga-germany
- Ligue 1 Uber Eats logo reference: https://commons.wikimedia.org/wiki/File:Ligue_1_Uber_Eats.svg
