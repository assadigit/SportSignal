# Match hero banner — visual implementation specs

These specs define a restrained, cinematic depth pass for the existing upcoming-match hero banner. They are intended for an agentic coding assistant working inside the website repository.

## Files

- `01-player-shadow-silhouettes.md` — directional projected silhouettes on the HUD, including robust LTR/RTL behavior.
- `02-floating-particles.md` — a small, quiet ambient particle layer.
- `03-hud-depth-and-edge-glow.md` — panel gradient, inner highlights, frame depth, and edge-localized glow.
- `04-directional-player-rim-light.md` — faint, inward-facing blue contour light without a full neon outline.
- `05-implementation-and-qa.md` — order of work, shared stacking rules, responsive and visual QA acceptance criteria.
- `START_NEW_SESSION_PROMPT.md` — copy/paste prompt for a fresh coding-agent session.

## Non-negotiable constraints

1. Audit the existing code and asset pipeline before editing. Preserve the current composition, team/player selection, fixture data, Persian/RTL content, and established brand style.
2. Make incremental changes and inspect the actual browser render after each visual layer. Do not guess at the existing framework, selectors, or file paths.
3. Treat the left/right side as a **physical screen-space position**, not as a team identity, DOM order, or text direction. Text direction may change without reversing lighting direction.
4. Reuse the original transparent player PNG's alpha for shadow/rim effects. Do not trace a rough new silhouette if the PNG already has a clean alpha channel.
5. Effects must remain subordinate to the matchup information. No heavy neon outline, conspicuous ghost-player, excessive particles, or broad screen-wide glow.
6. Respect `prefers-reduced-motion`, keep decorative layers non-interactive and hidden from assistive technology, and avoid unnecessary JavaScript animation loops or dependencies.

## Intended layering model

Use the existing stacking contexts where possible. The conceptual order is:

| Layer | Suggested stacking role | Purpose |
|---|---:|---|
| Stadium/background art | 0 | Existing background image and atmosphere |
| Ambient particles | 1 | Barely visible motion in free background areas |
| HUD face/frame | 10 | Existing panel and its frame |
| Projected player-shadow plane | 20 | Shadows clipped to the actual HUD face |
| HUD text, logos, clock, labels | 25 | Keep essential information clear above shadows |
| Foreground player cutouts | 30 | Players remain crisp and in front |

These values are guidance, not a mandate to create new stacking contexts everywhere. Existing `transform`, `filter`, `opacity`, `isolation`, and positioned ancestors can create stacking contexts. Verify actual stacking in the browser inspector.

## Shared visual starting point

Use these as tuning ranges, not guaranteed final values:

- Projected shadow: roughly 10–18% opacity, 10–18 px blur, 22–38 px inward displacement, 7–14 px downward displacement.
- Particle layer: about 6–12 visible particles on desktop and 3–6 on small screens; mostly 1–2 px points at 4–14% opacity.
- HUD inner highlight: a faint 1 px upper-edge highlight and low-opacity inset blue ambience.
- HUD edge glow: localized and low-opacity, normally no more than about 8–14 px blur.
- Player rim light: one-directional, blue, and much weaker than the PNG's existing highlights; start around 8–16% alpha for the tight component and 5–10% for the diffuse component.

Judge the final values at the actual 1884 × 603 reference-banner proportions as well as the site's supported breakpoints. When an effect looks obvious before the viewer notices the match, reduce it.
