# Spec 05 — Implementation order, integration, and QA

## Implementation order

Work in this order so each effect can be evaluated independently:

1. **Repository audit and baseline capture.** Find the hero component, player-image source and sizing, HUD frame/face assets, z-index/overflow rules, responsive breakpoints, and fixture/team-selection logic. Run the project and capture desktop plus mobile baselines.
2. **HUD layering and face geometry.** Identify the true inner HUD face shape and ensure its clipping/mask is reusable. Establish stable stacking behavior without changing the design.
3. **Player cast-shadow plane.** Add the alpha-derived duplicate silhouettes. Tune left/right screen-space vectors and clip to the HUD's inner face. Verify shadows sit below HUD content and above the HUD face.
4. **HUD depth.** Add a subtle interior gradient/highlight and a restrained physical frame shadow/edge glow. Compare against the existing frame artwork to avoid stacking redundant effects.
5. **Directional rim light.** Add only after shadow/HUD depth are correct. Tune the inward contour accent separately for each physical side.
6. **Particles.** Add last, so ambient motion cannot mask contrast issues or distract from more important layers.
7. **Responsive and accessibility pass.** Verify LTR and RTL, desktop/mobile, slow image loading, different player aspect ratios, reduced motion, and long or translated team names.

## Shared direction contract

Use one implementation-level notion of `physicalSide`, e.g. `left` or `right`, derived from the rendered layout. This can be encoded as a data attribute/class or passed as a prop. It must not be computed from the language or text direction.

Conceptual mapping:

| Actual rendered side | Shadow X | Rim-light X | Vertical shadow |
|---|---:|---:|---:|
| Left | positive / rightward | positive / rightward | positive / downward |
| Right | negative / leftward | negative / leftward | positive / downward |

A test that only toggles `dir="ltr"` to `dir="rtl"` while keeping player positions unchanged must not change these directions.

## Suggested semantic structure

Adapt to the framework and current component structure; these names are conceptual, not prescribed:

```text
match-hero (positioning context)
├── stadium-background
├── ambient-particles (aria-hidden)
├── hud-frame-and-face
├── projected-shadow-plane (clipped to HUD inner face; aria-hidden)
│   ├── left-player-shadow-copy
│   └── right-player-shadow-copy
├── hud-content (logos, names, clock, countdown, venue)
└── foreground-player-cutouts
```

The shadow copies must share positioning variables or measurements with their foreground players. Do not duplicate hard-coded offsets in two unrelated layout systems. If the project structure demands a different DOM order, preserve the same visual stacking and clipping relationships.

## Browser and responsive checks

- Inspect the real render at the supplied wide-banner proportions (approximately 1884 × 603) and at all actual project breakpoints.
- Test `dir="ltr"` and `dir="rtl"` with the physical player positions unchanged.
- Test with two substantially different player cutouts (different crop, transparent padding, pose, and image dimensions). Effects must respect actual alpha boundaries, not a guessed body outline.
- If the current fixture data can switch player sides, verify that the physical-side property follows the rendered position.
- Check that CSS filters, opacity, `transform`, and `clip-path` have not introduced unexpected stacking contexts or clipping.
- Check image loading before and after the original PNG becomes available; no visible layout shift should be introduced.
- Check narrow screens where the desktop layout may be changed or players may overlap differently. Reduce or disable effects if the player-to-HUD geometry no longer supports the same projection.
- Check contrast on the central clock/countdown and team names.
- Check `prefers-reduced-motion: reduce`; particles should stop moving. Shadows and static depth may remain.
- Check no particle/shadow layer catches pointer events, adds accessibility noise, or changes page scroll.
- Run available lint, type-check, and build/test commands.

## Acceptance criteria

### Cast shadows
- Left physical player casts right/down; right physical player casts left/down.
- Direction does not depend on LTR vs RTL or team identity.
- Shadows derive from real PNG transparency and are clipped to the actual HUD face.
- Original player images remain sharp and dominant; no visible rectangular image shadow or conspicuous duplicate-player ghost.
- Central HUD content remains clear.

### HUD depth
- Interior feels subtly darker and dimensional.
- There is a restrained internal highlight and a soft shadow grounding the outer frame.
- Blue glow is local to the perimeter, not a broad light cloud across the hero.
- Existing angular frame shape, team identity, and typography are preserved.

### Rim light
- Cool blue accent is faint and biased toward the HUD-facing edge.
- No strong all-around cyan outline; source image lighting remains dominant.
- Direction follows physical placement and is independent of text direction.

### Particles
- Few, very low-contrast particles with slow motion; they are not the focal point.
- They avoid faces, logos, and essential match information.
- They are decorative, non-interactive, and static when reduced motion is requested.

## Completion report from the coding agent

When finished, report:

1. Files/components changed.
2. How the physical-side direction is resolved in the existing layout.
3. Which asset/mask/clip path is used for the HUD-face shadow clipping.
4. Actual final effect values, and which desktop/mobile states were checked.
5. Build/lint/test results and any known limitation.
