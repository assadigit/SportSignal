# Spec 03 — HUD depth, restrained inner highlights, and edge-localized glow

## Goal

Make the central match HUD feel like a dimensional, engineered panel integrated into the stadium. The surface should be darker and slightly more layered, with a soft physical shadow beneath the frame and restrained light near the edges. Preserve the existing angular blue design; do not redesign it as a generic card.

## Required changes

### 1. Darker interior face

Use a dark navy-to-deep-blue interior gradient so match information remains prominent. Suggested starting palette (sample against existing artwork before committing):

- Upper face: `#0C2B50` to `#103D6A`
- Middle face: `#071D3A`
- Lower/deep face: `#04142B`

Use translucent overlays if the current HUD already has a detailed background texture. Keep enough of the existing texture visible to avoid a flat, plastic rectangle. The gradient belongs to the panel's **face**, not across the entire banner.

### 2. Inner upper-edge highlight

Add one subtle inset highlight to suggest a light source above the panel. It should be roughly a 1 px line or a faint internal wash, with low opacity (often around 0.08–0.16). A second, weaker inner blue ambience may be used near the sides, but should not make the face uniformly glow.

Illustrative CSS for an existing rectangular/panel face (adapt to the real structure):

```css
.match-hud__face {
  background: linear-gradient(
    180deg,
    rgb(17 57 99 / 0.88) 0%,
    rgb(7 29 58 / 0.94) 52%,
    rgb(3 17 38 / 0.97) 100%
  );
  box-shadow:
    inset 0 1px 0 rgb(190 230 255 / 0.12),
    inset 0 0 20px rgb(20 110 255 / 0.07);
}
```

Do not apply this block verbatim if the panel uses an existing textured PNG/SVG or a custom polygon; preserve the source art and put the gradient/highlight in a correctly clipped overlay.

### 3. Soft frame shadow below the panel

Add depth mainly beneath and slightly around the frame, with neutral dark shadow. A reasonable starting point is `0 12px 24px rgb(0 0 0 / 0.22)`; tune for the actual size and background contrast. The effect should attach to the HUD silhouette rather than a visible rectangular bounding box.

- For a transparent frame PNG/SVG or clipped shape, `filter: drop-shadow(...)` may follow the shape's alpha/clip more accurately than a box shadow.
- For a normal rectangular face, an appropriate `box-shadow` can be used.
- Avoid multiple heavy stacked shadows. One soft physical shadow is normally enough.

### 4. Localized blue edge glow

Keep the current electric-blue accent close to the HUD's perimeter. Aim for a restrained 6–14 px blur at low opacity (commonly 0.08–0.16 alpha, depending on the original artwork), rather than a broad glow washing over the stadium.

- Use an existing border/frame asset as the primary source of the blue edge.
- If a pseudo-element is added, align it exactly to the panel shape and mask its interior so the glow does not flood the whole panel.
- Prefer a narrow highlight along the top/side edges and a dimmer glow underneath.
- Keep the HUD face darker than the edge accents so the frame reads crisply.
- Preserve angular corners and any central notches; do not replace them with rounded-card styling.

## Layer and clipping rules

- Do not let HUD gradients cover team logos, text, or the central clock.
- Clip surface gradients and inner highlights to the **interior face**. Use the frame's own silhouette/mask if it is not rectangular.
- Keep the outer shadow behind the frame; do not place it on top of the text or foreground player images.
- If a CSS `filter` creates an unexpected stacking context or changes z-index behavior, adjust the component structure rather than layering increasingly large z-index values.

## Anti-patterns

- Adding more and brighter neon glow to an already bright blue border.
- A large blue bloom across the stadium or behind player faces.
- A hard black shadow that looks like a flat offset duplicate.
- Covering or flattening existing HUD artwork without inspecting its source layers.
- A rectangular shadow visible outside an angular HUD panel.

## Acceptance checks

- The panel interior reads slightly darker and more legible than before.
- The top/inner edge catches light subtly; the face still looks dimensional rather than flat.
- A soft shadow grounds the frame without making the banner look heavy.
- Blue glow remains close to the frame perimeter.
- The existing HUD geometry, team elements, and typography remain intact at every supported breakpoint.
