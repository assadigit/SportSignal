# Spec 01 — Directional player silhouettes cast onto the HUD

## Goal

Make each cutout player feel physically in front of the central HUD by projecting a faint, soft silhouette onto the **interior face** of the panel. The effect should look like a shadow, not a second translucent player, an outer glow, or a rectangular box shadow.

## Direction rules: physical sides, never text direction

The shadow vector points inward toward the center of the banner and slightly down:

- **Player currently rendered on the physical left side of the viewport:** shadow moves right (`+X`) and down (`+Y`).
- **Player currently rendered on the physical right side of the viewport:** shadow moves left (`−X`) and down (`+Y`).

This rule must remain true in both LTR and RTL pages. Do not infer it from `dir`, `direction`, the team name, which team is “home”, or whether an item is first in the DOM. Resolve the player's **actual physical placement** from the hero layout. If the layout swaps players for any reason, update the physical-side assignment along with the placement. If the mobile composition changes sides or stacks the players, recalculate or disable the cast shadow as appropriate.

Keep decorative image/shadow positioning in screen-space coordinates. Applying `direction: ltr` to a decorative scene layer is acceptable if it prevents inherited RTL behavior from changing coordinates; do not force text content to LTR.

## Required rendering strategy

1. Reuse the same transparent PNG/asset source as the foreground cutout. The alpha channel defines the silhouette.
2. Render one or two decorative copies on a separate **projected-shadow plane**, above the HUD face but below HUD content and the foreground players.
3. Position each copy from the same source of truth as its foreground player's box, dimensions, object-fit, scale, and placement. Do not maintain a second set of hand-tuned coordinates that will drift out of alignment.
4. Make the copy black using `brightness(0)` or an equivalent alpha-preserving method. Apply opacity, blur, and a translation toward the banner center.
5. Clip/mask the *shadow plane* to the actual inner HUD face, not merely the player's own bounding box. Reuse the existing HUD SVG mask, clip path, or shape asset if available. If there is no reusable shape, add a responsive mask that matches the panel's interior silhouette and excludes the bright outer border. Do not guess with a large rectangle if the panel has angular/notched edges.
6. Keep HUD text, team logos, clock, countdown, and other high-priority labels above the shadow plane. The shadow should not reduce text contrast.
7. Keep the original foreground PNG crisp and above its projected shadow. Never blur or darken the visible foreground player to create the cast-shadow effect.
8. Ensure the decorative duplicates do not add accessible duplicate content: use `alt=""`, `aria-hidden="true"`, and `pointer-events: none`.

## Recommended two-component shadow

Use two subtle copies when the result benefits from depth. Omit the tighter component if it makes the PNG look doubled.

| Component | Purpose | Initial desktop tuning range |
|---|---|---|
| Soft body shadow | Main broad projected silhouette | inward X 22–38 px; down Y 8–14 px; blur 12–18 px; opacity 0.10–0.16 |
| Near/contact component | Adds a slightly denser attachment close to the player | inward X 8–16 px; down Y 3–7 px; blur 2–5 px; opacity 0.04–0.09 |

Use a multiply-style blend only if it improves the actual blue HUD face and does not muddy the panel. Start with a neutral black shadow; do not make the cast shadow cyan. Keep any silhouette scaling close to 1 (`0.985–1.0` is a reasonable starting range) so it stays aligned with the source player rather than turning into a visibly separate ghost.

Suggested responsive displacement values:

```css
/* Assign by actual physical placement, not by dir or team identity. */
.player-shadow--physical-left {
  --cast-x: clamp(18px, 2vw, 36px);
  --cast-y: clamp(7px, 0.7vw, 14px);
}

.player-shadow--physical-right {
  --cast-x: clamp(-36px, -2vw, -18px);
  --cast-y: clamp(7px, 0.7vw, 14px);
}
```

These are only displacement variables; integrate them with the project's real DOM and positioning model.

## Stacking / clipping contract

Preferred conceptual order:

- HUD face and frame
- shadow plane clipped to the HUD's **inner face**
- HUD foreground content (names, clock, timer, logos)
- foreground player PNGs

The shadow plane needs hero-level coordinates so it can be clipped to the HUD mask while its copies still align with the player boxes. If the existing component structure makes this awkward, choose the simplest maintainable implementation that preserves these constraints; document any limitation rather than silently letting the shadow leak across the stadium background.

Do not let `overflow: hidden` on the player wrapper cut off the translated shadow. Avoid changing the clipping behavior of the complete hero merely to contain shadows.

## CSS behavior notes

- A `box-shadow` on an `<img>` is not silhouette-aware and must not be used as the main projected shadow.
- `filter: drop-shadow()` is alpha-aware and is suitable for subtle foreground separation, but a shadow made from a duplicate, darkened PNG gives more control over the cast direction and panel clipping.
- CSS `brightness(0)` on a transparent PNG should preserve the alpha shape. Confirm the actual assets have real transparency; if not, use a suitable cutout or mask rather than casting the image's rectangular background.
- Reusing the same asset URL should normally benefit from browser caching. Avoid fetching or decoding a different copy of the source solely for the effect unless the framework requires it.

## Anti-patterns

- Using `:dir(rtl)` to reverse the shadow direction.
- Setting the direction based on “Arsenal” or “Bayern” rather than physical position.
- Showing a clear, recognisable second person shape over the HUD.
- Letting the cast shadow darken the central clock, score, countdown, or logos.
- Applying an all-around blue glow and calling it a cast shadow.
- Clipping the player image itself to the HUD mask.

## Acceptance checks

- Left-positioned player casts right/down; right-positioned player casts left/down.
- Changing only the page's `dir` attribute does not reverse either shadow.
- If players swap physical positions, their shadow directions follow the new positions.
- Shadows are visible only on the HUD's interior face, not across the bright frame or unrelated stadium areas.
- The real PNG remains sharp; no visible rectangular edge appears; no duplicate-person silhouette dominates.
- Core HUD text and logos remain clear at desktop and mobile widths.
