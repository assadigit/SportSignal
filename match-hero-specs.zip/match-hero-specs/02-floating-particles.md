# Spec 02 — Barely visible ambient particles

## Goal

Add a small amount of atmospheric motion to the stadium scene without turning the hero into a particle effect. Particles should only be noticed on a second look and must never compete with faces, team crests, or match information.

## Visual specification

- Desktop target: approximately 6–12 visible particles at once.
- Mobile target: approximately 3–6; hide or omit the rest at narrow breakpoints.
- Particle diameter: mostly 1–2 CSS px; only a couple may reach 3 px.
- Color: cool blue, muted cyan, or neutral white sampled to harmonize with the existing stadium art.
- Normal opacity: approximately 0.04–0.14; rare peak opacity may approach 0.18, but should not flash.
- Glow: if needed, a small 2–4 px diffuse halo at low alpha, not a large neon bloom.
- Motion: slow drifting, about 18–36 seconds per cycle, with small travel distances (roughly 8–24 px) and staggered timings.
- Distribution: favor open stadium/background areas around the outer thirds and above or around the HUD. Keep the central reading area, player faces, team crests, clock, timer, and logos comparatively clear.

## Implementation guidance

1. Prefer a small, deterministic set of lightweight DOM elements styled with CSS, or a similarly lightweight existing particle utility if the project already has one. Do not add a particle library for this effect.
2. Use CSS transforms and opacity only. No per-frame JavaScript loop, continuous React state updates, or random values during render.
3. Place the particle layer behind the HUD and players. It may sit over the stadium background but should be naturally occluded by the HUD surface.
4. Mark the particle container `aria-hidden="true"` and set `pointer-events: none`; it must not affect clicks, selection, or keyboard navigation.
5. If the page already has ambient stadium particles/light texture, tune or reuse it instead of stacking a second competing system.
6. Avoid placing bright particles on top of faces, logos, score/time text, or the main HUD panel.
7. Use fixed/deterministic positions and staggered durations/delays to avoid hydration mismatch and avoid every particle moving in synchrony.

Example motion pattern, to be adapted to the project's naming/layout:

```css
.hero-particle {
  position: absolute;
  width: 2px;
  height: 2px;
  border-radius: 50%;
  background: rgb(150 220 255 / 0.65);
  opacity: 0.07;
  box-shadow: 0 0 3px rgb(65 170 255 / 0.18);
  pointer-events: none;
  animation: hero-particle-drift var(--particle-duration, 28s)
    ease-in-out var(--particle-delay, 0s) infinite alternate;
}

@keyframes hero-particle-drift {
  from { transform: translate3d(0, 5px, 0); opacity: 0.04; }
  to   { transform: translate3d(var(--particle-drift-x, 10px), -14px, 0); opacity: 0.12; }
}

@media (prefers-reduced-motion: reduce) {
  .hero-particle {
    animation: none;
    opacity: 0.06;
  }
}
```

The example is intentionally minimal. Assign varied positions, `--particle-duration`, `--particle-delay`, and `--particle-drift-x` to individual particles in the existing framework; do not paste a single particle in the center and duplicate it identically.

## Anti-patterns

- Large or high-contrast specks, sparkles, stars, snow, or confetti.
- Particles travelling across faces or important text.
- Synchronous blinking, fast movement, or flicker.
- JavaScript animation loops, canvas/WebGL, or a large dependency for a dozen tiny points.
- Making particles visible only by raising opacity until they compete with the scoreboard.

## Acceptance checks

- At full desktop size the particles provide atmosphere but are not the first thing noticed.
- They don't make the central HUD, faces, or logos harder to read.
- They do not intercept pointer input or produce assistive-technology noise.
- At small widths, particle count and contrast remain restrained.
- `prefers-reduced-motion: reduce` removes continuous particle movement.
