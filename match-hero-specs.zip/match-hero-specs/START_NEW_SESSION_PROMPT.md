# Prompt for a new coding-agent session

You are working on an existing website that has a dynamic upcoming-football-match hero banner. The banner uses a wide stadium background, a central angular blue HUD, team logos and match information, and transparent player PNG cutouts on the two sides. The current reference composition is approximately 1884 × 603 px. The website includes Persian/RTL content, and it may also render in LTR.

## First, read these specifications completely

- `README.md`
- `01-player-shadow-silhouettes.md`
- `02-floating-particles.md`
- `03-hud-depth-and-edge-glow.md`
- `04-directional-player-rim-light.md`
- `05-implementation-and-qa.md`

Treat them as the requirements for this task. If you do not have these files in the repository, ask me to provide/upload them before implementation rather than inventing their contents.

## Task

Implement the specified visual depth improvements in the existing hero banner:

1. Directional transparent-PNG silhouette shadows cast inward and slightly down onto the **inner face** of the HUD, with left/right direction based on actual physical screen position.
2. A small number of barely visible, slowly drifting ambient particles.
3. A darker, more dimensional HUD face with restrained inner highlights, a very soft physical shadow beneath the frame, and blue glow that stays close to the frame edges.
4. A very subtle cool-blue rim-light bias on the HUD-facing contours of the player cutouts, especially around shoulders/arms, without a strong outline around the whole body.

## Mandatory behavior and constraints

- Start by inspecting the repository and finding the real hero component, styles, player assets, HUD art/masks, image layout, responsive breakpoints, and fixture data flow. Run the app and inspect the baseline before editing.
- Do not rewrite the hero from scratch. Keep existing branding, artwork, dimensions/composition, club/team selection, fixture countdown/date/venue, fonts, language behavior, and accessibility.
- Make shadow and rim-light direction depend on **physical left/right placement**, not club identity, home/away, DOM order alone, or `dir="ltr"` / `dir="rtl"`. Changing only text direction must not flip lighting. If a player moves to the other physical side, update its direction accordingly.
- Use the existing transparent player PNG alpha for silhouettes. The cast shadow must be clipped to the HUD's actual inner face, excluding the bright frame if possible. Reuse an existing mask/clip path/shape asset or create a responsive one aligned to the panel. Do not shadow the PNG's rectangular box.
- Keep player originals crisp, HUD text and logos legible, and all effects understated. Avoid a visible second-player ghost, an all-around neon rim, and broad blue glow across the stadium.
- Make particles low-contrast, slow, decorative, `pointer-events: none`, and `aria-hidden="true"`; disable their motion under `prefers-reduced-motion: reduce`.
- Prefer CSS transforms/opacity over JavaScript loops. Avoid new dependencies unless the repository already uses them and they clearly solve an existing need.
- Preserve responsive behavior and test at the banner's wide reference proportions and actual mobile breakpoints. Do not assume every player PNG has the same dimensions or transparent padding.
- Keep changes focused and maintainable. Use existing conventions and the project's framework; do not guess selectors or source paths before inspecting files.

## Work process

1. Summarize the current implementation briefly after inspection: relevant files, the current stacking model, the HUD shape/mask source, and how player positions are determined.
2. Implement one layer at a time in this order: shared HUD-face geometry/stacking, cast shadows, HUD depth, directional rim light, particles, responsive/accessibility refinements.
3. Run the site and inspect the actual browser render after each major step. Tune values based on the actual PNGs, not just the CSS defaults in the specs.
4. Test both LTR and RTL without changing player physical positions, then test any state where player positions swap. Verify the inward shadow/rim directions stay correct.
5. Run the project's available lint, type-check, build, and relevant tests.
6. Report changed files, final values, LTR/RTL and responsive states checked, test results, and any limitations. Do not claim a visual check or test succeeded unless you actually ran it.

## Definition of done

The finished banner retains its existing identity, but its players feel more integrated in front of the HUD. Faint black silhouette shadows fall inward and slightly down only onto the HUD face; the panel gains restrained physical depth; a quiet blue contour lift appears mainly on HUD-facing player edges; and a few slow particles add atmosphere without competing with the match information. The result works in LTR and RTL, on desktop and mobile, and respects reduced-motion preferences.
