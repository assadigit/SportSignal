# Spec 04 — Subtle inward-facing cool-blue player rim light

## Goal

Integrate the cutout players into the cool stadium/HUD lighting with a faint blue edge lift on the contours facing the HUD. The effect is directional and secondary to real highlights already present in the player PNG. It must not form a uniform cyan outline around the entire body.

## Direction rules

Use physical screen-space position, just like the cast shadow:

- Player physically on the **left**: the accent is biased toward its right/inward-facing contour.
- Player physically on the **right**: the accent is biased toward its left/inward-facing contour.

The rule must be unchanged by `dir="ltr"` or `dir="rtl"`; if players move to the other physical side, the accent follows the new side. Do not select the lighting direction by team identity.

## Preferred implementation

1. Inspect the source PNG and existing filters first. If the asset already has a natural cool rim light, do not intensify it unnecessarily.
2. Start with a low-opacity, one-directional alpha-aware `drop-shadow()` on the actual PNG. A small horizontal offset toward the HUD concentrates the visible colored fringe on the exposed, inward-facing contours without tinting the entire body.
3. Keep the filter chain compatible with the current separation/contact shadow. If the framework combines filters in a component utility, extend that utility rather than overwriting existing filters.
4. Tune while zoomed to 100% and at normal viewing size. The effect should be perceived as environmental integration, not as a colored stroke.
5. If `drop-shadow()` is too uniform for the actual asset, only then consider a separate rim-light layer built from the PNG's alpha. Mask that layer directionally so it affects the contour facing the HUD; do not add a fully tinted duplicate over the player.

Illustrative starting point; merge with existing filter rules rather than copy/pasting blindly:

```css
/* Player on the physical left: light bias goes right, toward the HUD. */
.player--physical-left .player__image {
  filter:
    drop-shadow(2px 0 1px rgb(74 164 255 / 0.13))
    drop-shadow(4px 0 4px rgb(39 132 255 / 0.07));
}

/* Player on the physical right: light bias goes left, toward the HUD. */
.player--physical-right .player__image {
  filter:
    drop-shadow(-2px 0 1px rgb(74 164 255 / 0.13))
    drop-shadow(-4px 0 4px rgb(39 132 255 / 0.07));
}
```

These values are deliberately restrained. They are not a requirement to create a visible blue halo. If the original player image already has strong highlights or the blue effect becomes obvious at normal viewing size, reduce the alpha or remove the wider component.

## Where the effect should read

Prioritize naturally exposed contours such as shoulders, upper arms, and outer jersey edges facing the HUD/stadium. Avoid trying to draw a perfectly continuous rim around hair, face, torso, shorts, and legs. The source asset's highlights and shadows should remain the dominant lighting cues.

## Anti-patterns

- A full cyan/blue outline around the entire silhouette.
- A solid, tinted duplicate of the player layered visibly over the original.
- A high-intensity blur that changes the perceived player size or makes the PNG look cut out with a neon sticker border.
- Using `drop-shadow(0 0 8px cyan)` on every edge equally.
- Light direction tied to RTL, the club name, or home/away labels instead of physical placement.
- Overwriting other `filter` effects unintentionally.

## Acceptance checks

- A faint cool-blue edge lift is perceptible only on close inspection.
- It is stronger on the inward-facing side than the outward-facing side.
- Most of each player's original color, texture, and lighting remains unchanged.
- No continuous cyan outline is visible around the face, full torso, and legs.
- LTR/RTL changes do not reverse the rim-light direction; physical position changes do.
